# Gneiss Theme Website

A dark, layered website inspired by gneiss rock patterns.

## Features
- Dark layered gradients
- Modern card UI
- Hover animation effects

## Usage
Open index.html in your browser and customize freely.

## Author
Your Name
